#!/bin/sh
umask 022
basedir=$(cd `dirname $0`;pwd)
setenforce 0
cp /etc/selinux/config /etc/selinux/config.save
sed -i "s:SELINUX.*=.*:SELINUX=disabled:g" /etc/selinux/config
install -m644 "${basedir}/gost.service" /etc/systemd/system/
install -m755 "${basedir}/gost" /usr/local/bin/
systemctl daemon-reload
firewall-cmd --permanent --zone=public --add-port=4737/tcp
firewall-cmd --reload
systemctl enable gost --now
